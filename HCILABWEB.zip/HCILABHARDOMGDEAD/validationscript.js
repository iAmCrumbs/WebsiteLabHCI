let button = document.getElementById('button');
var dobirth = null;

window.addEventListener("DOMContentLoaded", e =>{
    dobirth = document.getElementById('dob');
})

button.addEventListener('click', e =>{
    let usernameElement = document.querySelector('#username');
    let emailElement = document.querySelector('#email');
    let passwordElement = document.getElementById('password')
    let regionElement = document.querySelector('#region');
    let dobElement = document.querySelector('#dob');
    let username = usernameElement.value;
    let email = emailElement.value;
    let password = passwordElement.value;
    let region = regionElement.value;


    var borndate = new Date(dobirth.value);

    var year = borndate.getFullYear();
    if(username === '')
    {
        alert('Username cannot be empty!');
    }

    if(username.length < 4 || username.length > 20)
    {
        alert('Username must contain more than 4 characters and less than 20 characters');
    }

    if(email.includes("@gmail.com") == false)
    {
        alert('You must use a gmail account to register! (@gmail.com)');
    }

    if(password === '')
    {
        alert('You must enter your password!');
    }

    if(password.length < 4 || password.length > 10)
    {
        alert("Your password must be between 4 to 10 characters");
    }

    if(year > 2002)
    {
        alert('You must be 18 years old to play this game (Year 2002)');
    }

});