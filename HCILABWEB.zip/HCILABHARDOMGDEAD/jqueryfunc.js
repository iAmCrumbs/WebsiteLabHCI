$(document).ready(function()
{
    $('.next').on('click', function()
    {
        var currimg = $('.active');
        var nextimg = currimg.next();

        if(nextimg.length)
        {
            currimg.removeClass('active').css('z-index', -10);
            nextimg.addClass('active').css('z-index', 10);
        }
    });

    $('.prev').on('click', function()
    {
        var currimg = $('.active');
        var previmg = currimg.prev();

        if(previmg.length)
        {
            currimg.removeClass('active').css('z-index', -10);
            previmg.addClass('active').css('z-index', 10);
        }
    });
});